#include <xc.h>
#include "pwm.h"



void InitializeTimer2For_PWM(void)
{
 
 //initTimer2
 T2CONbits.TON = 0 ;
 TMR2 = 0x0000;
 T2CON = 0x2000;  //prescale 1:256
 PR2 = 39062; //period value
 //IEC0bits.T2IE = 1;
 IFS0bits.T2IF= 0;
 RPOR10bits.RP21R = 18 ; // REMAP on RP21
 OC1R = 1000; // initial duty cycle 50%
 OC1RS = 1000; //duty cycle 50%
 OC1CON1bits.OCM = 0b000; // Clear whatever values are in
 OC1CON1bits.OCTSEL = 0b000; // Timer2 source 
 
 IPC0bits.OC1IP = 0x01;  // Set Output Compare 1 Interrupt Priority Level
 IFS0bits.OC1IF = 0;     // Clear Output Compare 1 Interrupt Flag
// IEC0bits.OC1IE = 1;     // Enable Output Compare 1 interrupt
 
 
 OC1CON1bits.OCM = 0b110; // edge PWM mode 
 T2CONbits.TON = 1 ;
 
}


void __attribute__((__interrupt__, no_auto_psv)) _OC1Interrupt( void )
{
//Interrupt Service Routine code goes here
IFS0bits.OC1IF = 0;     // Clear OC1 interrupt flag
//LATFbits.LATF1 =~  LATFbits.LATF1;
 
 

}

void __attribute__((__interrupt__, no_auto_psv)) _T2Interrupt( void )
{
    IFS0bits.T2IF = 0; 
//Interrupt Service Routine code goes here
    // Clear OC1 interrupt flag
//LATFbits.LATF1 =~  LATFbits.LATF1;


}






