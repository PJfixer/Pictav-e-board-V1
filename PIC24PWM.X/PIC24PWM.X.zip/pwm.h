/* 
 * File:   pwm.h
 * Author: pierre
 *
 * Created on 25 ao�t 2018, 21:51
 */

void InitializeTimer2For_PWM(void);
void Init_PWM(void);